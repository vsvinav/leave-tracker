package com.hashedin.tracker;

public enum LeaveStatus {
    ACCEPTED, REJECTED, PENDING
}
