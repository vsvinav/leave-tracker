package com.hashedin.tracker;

import java.util.HashMap;

public class DataStore {

}
