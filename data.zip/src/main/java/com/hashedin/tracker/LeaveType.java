package com.hashedin.tracker;

public enum LeaveType {
            OOO, compOff, maternityLeave, paternityLeave, general

}
