package com.hashedin.tracker;

public class EmployeeStore {
}
