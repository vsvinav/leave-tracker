package com.hashedin.tracker;

import org.junit.Test;

import java.time.LocalDate;
import java.time.Month;

import static org.junit.Assert.*;

public class LeaveAccrualManagerTest {
    Employee e = new Employee(1, "name", "designation", 2, false,"male",false, LocalDate.now(),LocalDate.of(2019,2,1),0,0);
    Employee e1 = new Employee(1, "name", "designation", 2, true,"female",false, LocalDate.now(),LocalDate.of(2019,1,1),0,0);
    @Test
    LeaveManager manager = new LeaveManager();
    LeaveRequest request = new LeaveRequest(1, LocalDate.now(), LocalDate.now().plusDays(2));
    LeaveAccrualManager accrualManager = new LeaveAccrualManager();

}